<?= $this->extend("templates") ?>
<?= $this->section("title") ?>

<!-- klo mau di ubah, ubah isinya aja yg di tag h2 -->
<h2>Lyrics Some | Bolbbalgan4</h2>

<?= $this->endSection() ?>

<?= $this->section("content") ?>
<br>
<p><strong>Sonora.ID</strong> - Berikut lirik dan terjemahan lagu 'Some' yang dipopulerkan Bolbbalgan4.</p>
<!-- klo gak mau tinggal apus yg di bawah, semua tag div -->
<!-- End DFP Inside MediumRectangle -->
<div>표현이 서툰 것도 잘못인가요</div>
<div>pyohyeoni seotun geosdo jalmosingayo</div>
<div>(Apakah salah jika aku tidak pandai mengekspresikannya?)&nbsp;</p>
    <p>나 차가운 도시에 따뜻한 여잔데
</div>
<div>na chagaun dosie ttatteushan yeojande</div>
<div>(aku seorang gadis yang hangat di kota yang dingin ini)&nbsp;</div>
<div>&nbsp;</div>
<div>그냥 좋아한단 말도 안 되는가요</div>
<div>geunyang johahandan maldo an doeneungayo</div>
<div>(bolehkah aku mengatakan bahwa aku menyukaimu? )&nbsp;</div>
<div>&nbsp;</div>
<div>솔직하게 난 말하고 싶어요</div>
<div>soljikhage nan malhago sipeoyo</div>
<div>(Aku hanya ingin jujur)&nbsp;</div>
<div>&nbsp;</div>
<div>사라져 아니 사라지지 마</div>
<div>sarajyeo ani sarajiji ma</div>
<div>(Pergilah, jangan pergi&nbsp;Jangan)&nbsp;</div>
<div>네 맘을 보여줘 아니 보여주지 마</div>
<div>ne mameul boyeojwo ani boyeojuji ma</div>
<div>(tunjukkan hatimu, tidak tidak tunjukkan kepadaku)&nbsp;</div>
<div><br />하루 종일 머릿속에 네 미소만</div>
<div><span>haru</span>&nbsp;jongil meorissoge ne misoman</div>
<div>(Sepanjang hari, hanya senyummu yang ada di kepalaku)&nbsp;</div>
<div><br />우리 그냥 한번 만나볼래요</div>
<div>uri geunyang hanbeon mannabollaeyo</div>
<div>(Apakah kamu ingin pergi keluar?)&nbsp;</div>
<div>&nbsp;</div>
<div>&nbsp;</div>
<div>나 오늘부터 너랑 썸을 한번 타볼 거야</div>
<div>na oneulbuteo neorang sseomeul hanbeon tabol geoya</div>
<div>(Mulai hari ini, aku akan memiliki sesuatu denganmu)&nbsp;</p>
    <p>나 매일매일 네게 전화도 할 거야
</div>
<div>na maeilmaeil nege jeonhwado hal geoya</div>
<div>(Aku akan menelponmu setiap hari)&nbsp;</div>
<div>밀가루 못 먹는 나를 달래서라도</div>
<div>milgaru mot meokneun nareul dallaeseorado</div>
<div>(Meskipun aku tidak bisa makan gluten?&nbsp;</div>
<div>너랑 맛있는 걸 먹으러 다닐 거야</div>
<div>neorang masissneun geol meogeureo danil geoya</div>
<div>(aku akan pergi makan makana lezat bersamamu)&nbsp;</div>
<div>&nbsp;</div>
<div>&nbsp;</div>
<div>넘넘 스윗한 넌 정말 달콤한 걸</div>
<div>neomneom seuwishan neon jeongmal dalkomhan geol</div>
<div>(Begitu manisnya, kamu benar-benar sangat manis)&nbsp;</div>
<div>넘넘 스윗한 넌</div>
<div>neomneom seuwishan neon</div>
<div>(Begitu manisnya dirimu)&nbsp;</div>
<div>&nbsp;</div>
<div>&nbsp;</div>
<div>그냥 좋아한단 말도 안 되는가요</div>
<div>geunyang johahandan maldo an doeneungayo</div>
<div>(Bolehkah aku mengatakan bahwa aku menyukaimu?)&nbsp;</div>
<div>솔직하게 난 말하고 싶어요</div>
<div>soljikhage nan malhago sipeoyo</div>
<div>(Aku&nbsp;hanya ingin&nbsp;jujur)&nbsp;</div>
<div>&nbsp;</div>
<div>&nbsp;</div>
<div>사라져 아니 사라지지 마</div>
<div>sarajyeo ani sarajiji ma</div>
<div>(Pergilah, jangan pergi Jangan)&nbsp;</div>
<div>네 맘을 보여줘 아니 보여주지 마</div>
<div>ne mameul boyeojwo ani boyeojuji ma</div>
<div>(tunjukkan hatimu, tidak tidak tunjukkan kepadaku)&nbsp;</div>
<div>하루 종일 머릿속에 네 미소만</div>
<div>haru&nbsp;jongil meorissoge ne misoman</div>
<div>(Sepanjang hari, hanya senyummu yang ada di kepalaku)&nbsp;</div>
<div>우리 그냥 한번 만나볼래요</div>
<div>uri geunyang hanbeon mannabollaeyo</div>
<div>(Apakah kamu ingin&nbsp;pergi&nbsp;keluar?)&nbsp;</div>
<div>&nbsp;</div>
<div>&nbsp;</div>
<div>나 오늘부터 너랑 썸을 한번 타볼 거야</div>
<div>na oneulbuteo neorang sseomeul hanbeon tabol geoya</div>
<div>(Mulai hari ini, aku akan memiliki sesuatu denganmu)&nbsp;</div>
<div>나 매일매일 네게 전화도 할 거야</div>
<div>na maeilmaeil nege jeonhwado hal geoya</div>
<div>(Aku akan menelponmu setiap hari)&nbsp;</div>
<div>밀가루 못 먹는 나를 달래서라도</div>
<div>milgaru mot meokneun nareul dallaeseorado</div>
<div>(Meskipun aku tidak bisa makan&nbsp;gluten)&nbsp;</div>
<div>너랑 맛있는 걸 먹으러 다닐 거야</div>
<div>neorang masissneun geol meogeureo danil geoya</div>
<div>(aku akan pergi makan&nbsp;makanan lezat&nbsp;bersamamu)&nbsp;</div>
<div>&nbsp;</div>
<div>&nbsp;</div>
<div>사랑은 이렇게 생기는 게 아니겠어</div>
<div>sarangeun ireohge saenggineun ge anigesseo</div>
<div>(Bukankah begitulah cinta dimulai&nbsp;?)&nbsp;</div>
<div>어쩌면 내 맘의 반쪽을</div>
<div>eojjeomyeon nae mamui banjjogeul</div>
<div>(Mungkin seperti menggantung)&nbsp;</div>
<div>네게 걸어보는 건데</div>
<div>nege georeoboneun geonde</div>
<div>&nbsp;(setengah hatiku padamu)&nbsp;</div>
<div>나는 오늘도 네게 차일 것만 같아도</div>
<div>naneun oneuldo nege chail geosman gatado</div>
<div>(Meskipun rasanya seperti kammu akan menolakku)</div>
<div>난 한번 더 너에게 다시 달려가 볼 거야</div>
<div>nan hanbeon deo neoege dasi dallyeoga bol geoya</div>
<div>(Aku akan mencobanya sekali lagi)&nbsp;</div>
<div>&nbsp;</div>
<div>&nbsp;</div>
<div>나 오늘부터 너랑 썸을 한번 타볼 거야</div>
<div>na oneulbuteo neorang sseomeul hanbeon tabol geoya</div>
<div>(Mulai hari ini, aku akan memiliki sesuatu denganmu)&nbsp;</div>
<div>나 매일매일 네게 전화도 할 거야</div>
<div>na maeilmaeil nege jeonhwado hal geoya<br />(Aku akan menelponmu setiap hari)&nbsp;</div>
<div>매운 거 못 먹는 나를 달래서라도</div>
<div>maeun geo mot meokneun nareul dallaeseorado</div>
<div>(Meskipun aku tidak bisa makan&nbsp;gluten)</div>
<div>너랑 맛있는 걸 먹으러 다닐 거야</div>
<div>neorang masissneun geol meogeureo danil geoya</div>
<div>(aku akan pergi makan&nbsp;makanan lezatbersamamu)&nbsp;</div>
<div>&nbsp;</div>
<div>&nbsp;</div>
<div>나도 그 애처럼 좋아요 좀 눌러줘</div>
<div>nado geu aecheoreom johayo jom nulleojwo</div>
<div>(tekan "seperti" pada fotoku&nbsp;eperti yang kamu lakukan padanya)&nbsp;</div>
<div>나도 너랑 말 좀 할 수 있게 해줘</div>
<div>nado neorang mal jom hal su issge haejwo</div>
<div>(Biarkan aku berbicara&nbsp;denganmu juga)&nbsp;</div>
<div>나는 풀이 죽어서 오늘도 포기하고</div>
<div>naneun puri jugeoseo oneuldo pogihago</div>
<div><span>(aku merasa sangat&nbsp;</span>kesal sehingga aku menyerah hari ini)&nbsp;</div>
<div>뒤를 돌아볼 때쯤 나를 붙잡는 넌</div>
<div>dwireul dorabol ttaejjeum nareul butjapneun neon</div>
<div>(Hanya ketika aku akan menengok ke belakang, kamu memegangku)&nbsp;</div>
<div>&nbsp;</div>
<div>넘넘 스윗한 넌 정말 달콤한 걸</div>
<div>neomneom seuwishan neon jeongmal dalkomhan geol</div>
<div>(Begitu manisnya, kamu benar-benar sangat manis)&nbsp;</div>
<div>넘넘 스윗한 넌</div>
<div>neomneom seuwishan neon</div>
<div>(Begitu manisnya dirimu)&nbsp;</div>
</p>
<!--unruly start -->



<?= $this->endSection() ?>